letter_tribble <-
  tribble(
  )
